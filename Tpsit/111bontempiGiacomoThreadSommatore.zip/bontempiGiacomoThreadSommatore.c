#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

typedef struct {
 			int a;
 			int b;
}Parametri;
typedef struct {
	int a; 
}Risultato;

void* my_thread(void*);

int main(int argc, char const *argv[])
{
	if(argc != 3){
		printf("USAGE: %s PARAM#1, PARAM#2\n", argv[0]);
		return -1;
	}
	
	int pid = getpid();
	Parametri* param = (Parametri*) malloc(sizeof(Parametri));
	param->a = atoi(argv[1]);
	param->b = atoi(argv[2]);

	pthread_t thread_id;
	int ris = pthread_create(&thread_id, NULL, my_thread, param);
	if(ris != 0){
		printf("Errore nella creazione del thread %d\n", pid);
		return -2;
	}

	Risultato* somma;
	pthread_join(thread_id, (void**)somma);
	printf("La somma tra i due parametri e' di %s\n", *somma);
	free(somma);

	return 0;
}

void* my_thread(void* param){
	Parametri *valori = (Parametri*) param;
	int *somma = (int*) param;
	somma = valori->a + valori->b;
	pthread_exit(somma);
}